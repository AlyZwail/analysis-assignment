


import java.util.Iterator;

public class iterative {
	public static int loop(int s,int z) {
		int ans=1;
		for (int i = 0; i < z; i++) {
			ans*=s;			
		}
		return ans;
	}
	public static void main(String[] args) {
		System.out.println(loop(2,5));
	}
}	