import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class utilize {

	public static List<int[]> findPairsWithSum(int[] S, int t) {
		Arrays.sort(S);
		List<int[]> pairs = new ArrayList<>();

		for (int i = 0; i < S.length - 1; i++) {
			int complement = t - S[i];
			int index = binarySearch(S, complement, i + 1);

			if (index != -1) {
				int[] pair = { S[i], S[index] };
				pairs.add(pair);
			}
		}

		return pairs;
	}

	public static int binarySearch(int[] S, int t, int s) {
		int l = s;
		int r = S.length - 1;

		while (l <= r) {
			int mid = l + (r - l) / 2;

			if (S[mid] == t) {
				return mid;
			} else if (S[mid] < t) {
				l = mid + 1;
			} else {
				r = mid - 1;
			}
		}

		return -1;
	}

	public static void main(String[] args) {
		int[] S = { 3, 7, 2, 9, 1, 5, 4 };
		int t = 10;
		List<int[]> pairs = findPairsWithSum(S, t);

		if (pairs.isEmpty()) {
			System.out.println("No pairs found with the given sum.");
		} else {
			System.out.println("Pairs with the sum " + t + ":");
			for (int[] pair : pairs) {
				System.out.println(pair[0] + " and " + pair[1]);
			}
		}
	}
}