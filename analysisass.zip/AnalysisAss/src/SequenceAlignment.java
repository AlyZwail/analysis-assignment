public class SequenceAlignment {

    private static final int A = 0;
    private static final int G = 1;
    private static final int T = 2;
    private static final int C = 3;
    private static final int GAP = 4;

    private static final double THRESHOLD = 1e-10;


    public static Object[] sequenceAlignment(String a, String b, double[][] Matrix) {
        int x = a.length();
        int y = b.length();

        double[][] dynamicp = new double[x + 1][y + 1];
        for (int j = 1; j <= y; j++) {
        	dynamicp[0][j] = dynamicp[0][j - 1] + Matrix[GAP][charToIndex(b.charAt(j - 1))];
        }
        for (int i = 1; i <= x; i++) {
        	dynamicp[i][0] = dynamicp[i - 1][0] + Matrix[charToIndex(a.charAt(i - 1))][GAP];
        }

        for (int i = 1; i <= x; i++) {
            for (int j = 1; j <= y; j++) {
                char xChar = a.charAt(i - 1);
                char yChar = b.charAt(j - 1);

                double match = dynamicp[i - 1][j - 1] + Matrix[charToIndex(xChar)][charToIndex(yChar)];
                double delete = dynamicp[i - 1][j] + Matrix[charToIndex(xChar)][GAP];
                double insert = dynamicp[i][j - 1] + Matrix[GAP][charToIndex(yChar)];

                dynamicp[i][j] = Math.max(match, Math.max(delete, insert));
            }
        }

        StringBuilder alignedSequence1 = new StringBuilder();
        StringBuilder alignedSequence2 = new StringBuilder();
        int i = x, j = y;

        while (i > 0 || j > 0) {
            char xChar = (i > 0) ? a.charAt(i - 1) : '-';
            char yChar = (j > 0) ? b.charAt(j - 1) : '-';

            if (i > 0 && j > 0 && dynamicp[i][j] == dynamicp[i - 1][j - 1] + Matrix[charToIndex(xChar)][charToIndex(yChar)]) {
                alignedSequence1.insert(0, xChar);
                alignedSequence2.insert(0, yChar);
                i--;
                j--;
            } else if (i > 0 && dynamicp[i][j] == dynamicp[i - 1][j] + Matrix[charToIndex(xChar)][GAP]) {
                alignedSequence1.insert(0, xChar);
                alignedSequence2.insert(0, '-');
                i--;
            } else {
                alignedSequence1.insert(0, '-');
                alignedSequence2.insert(0, yChar);
                j--;
            }
        }

        double alignmentScore = dynamicp[x][y];
        if (Math.abs(alignmentScore) < THRESHOLD) {
            alignmentScore = 0.0;
        }

        return new Object[]{alignedSequence1.toString(), alignedSequence2.toString(), alignmentScore};
    }
    

    private static int charToIndex(char c) {
        switch (c) {
            case 'A':
                return A;
            case 'G':
                return G;
            case 'T':
                return T;
            case 'C':
                return C;
            case '-':
                return GAP;
            default:
                throw new IllegalArgumentException("Invalid character: " + c);
        }
    }
    public static void main(String[] args) {
        double[][] Matrix = {
                {1, -0.8, -0.2, -2.3, -0.6},
                {-0.8, 1, -1.1, -0.7, -1.5},
                {-0.2, -1.1, 1, -0.5, -0.9},
                {-2.3, -0.7, -0.5, 1, -1},
                {-0.6, -1.5, -0.9, -1, Double.NEGATIVE_INFINITY}
        };

        String a = "ATGCC";
        String b = "TACGCA";
      //  String a = "TCCCAGTTATGTCAGGGGACACGAGCATGCAGAGAC";
      //  String b = "AATTGCCGCCGTCGTTTTCAGCAGTTATGTCAGATC";

        Object[] res = sequenceAlignment(a, b, Matrix);

        System.out.println("Sequence 1: " + res[0]);
        System.out.println("Sequence 2: " + res[1]);
        System.out.println("Score: " + res[2]);
    }
    
}