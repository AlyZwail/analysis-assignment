package assignmentan;

import java.util.*;

class Graph {
    private Map<Integer, List<Integer>> graph = new HashMap<>();

    public void addEdge(int u, int v) {
        graph.computeIfAbsent(u, k -> new ArrayList<>()).add(v);
    }

    public void dfs(int start, String order) {
        Set<Integer> visited = new HashSet<>();
        Stack<Integer> stack = new Stack<>();
        stack.push(start);

        while (!stack.isEmpty()) {
            int node = stack.pop();
            if (!visited.contains(node)) {
                visited.add(node);
                System.out.print(node + " ");

                List<Integer> neighbors = graph.getOrDefault(node, Collections.emptyList());
                if (order.equals("left")) {
                    Collections.sort(neighbors, Collections.reverseOrder());
                } else {
                    Collections.sort(neighbors);
                }

                stack.addAll(neighbors);
            }
        }
    }

    public void bfs(int start, String order) {
        Set<Integer> visited = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);

        while (!queue.isEmpty()) {
            int node = queue.poll();
            if (!visited.contains(node)) {
                visited.add(node);
                System.out.print(node + " ");

                List<Integer> neighbors = graph.getOrDefault(node, Collections.emptyList());
                if (order.equals("left")) {
                    Collections.reverse(neighbors);
                }

                queue.addAll(neighbors);
            }
        }
    }

    private boolean hasCycle(int start, Set<Integer> visited, List<Integer> currentCycle) {
        visited.add(start);
        currentCycle.add(start);

        List<Integer> neighbors = graph.getOrDefault(start, Collections.emptyList());
        for (int neighbor : neighbors) {
            if (!visited.contains(neighbor)) {
                if (hasCycle(neighbor, visited, currentCycle)) {
                    return true;
                }
            } else {
                int index = currentCycle.indexOf(neighbor);
                List<Integer> cycle = new ArrayList<>(currentCycle.subList(index, currentCycle.size()));
                System.out.println("Cycle: " + cycle);
                return true;
            }
        }

        currentCycle.remove(currentCycle.size() - 1);
        return false;
    }

    public void detectCycle() {
        Set<Integer> visited = new HashSet<>();
        List<Integer> currentCycle = new ArrayList<>();

        for (int node : graph.keySet()) {
            if (!visited.contains(node)) {
                if (hasCycle(node, visited, currentCycle)) {
                    return;
                }
            }
        }

        System.out.println("No cycles found.");
    }

    public boolean isBipartite() {
        Map<Integer, String> colors = new HashMap<>();
        Set<Integer> visited = new HashSet<>();

        for (int node : graph.keySet()) {
            if (!visited.contains(node)) {
                Queue<Integer> queue = new LinkedList<>();
                queue.add(node);
                colors.put(node, "red");

                while (!queue.isEmpty()) {
                    int current = queue.poll();
                    String color = colors.get(current);

                    if (visited.contains(current)) {
                        if (!color.equals(colors.get(current))) {
                            return false;
                        }
                        continue;
                    }

                    visited.add(current);

                    List<Integer> neighbors = graph.getOrDefault(current, Collections.emptyList());
                    for (int neighbor : neighbors) {
                        queue.add(neighbor);
                        colors.put(neighbor, color.equals("red") ? "blue" : "red");
                    }
                }
            }
        }

        return true;
    }

    public static void main(String[] args) {
        Graph g = new Graph();
        g.addEdge(1, 3);
        g.addEdge(1, 4);
        g.addEdge(2, 1);
        g.addEdge(2, 3);
        g.addEdge(3, 4);
        g.addEdge(4, 1);
        g.addEdge(4, 2);

        System.out.println("DFS (left order):");
        g.dfs(1, "left");
        System.out.println("\nBFS (left order):");
        g.bfs(1, "left");

        System.out.println("\nCycles:");
        g.detectCycle();

        if (g.isBipartite()) {
            System.out.println("The graph is bipartite.");
        } else {
            System.out.println("The graph is not bipartite.");
        }
        /*To determine whether an undirected graph is a tree:

		Connectedness: Make sure all nodes are reachable from each other. If there are disconnected portions, it's not a tree.
		Acyclic: Confirm that there are no cycles (closed loops). If you find a cycle, it's not a tree.
		You can use Depth-First Search (DFS) or Breadth-First Search (BFS) to traverse the graph and check these conditions. If all nodes are visited and there are no cycles, the graph is a tree.

		Running Time:
		The time it takes is proportional to the number of nodes (V) and edges (E) in the graph, expressed as O(V + E).
         	*/
    }
}

